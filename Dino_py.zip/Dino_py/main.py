import pygame
import random
import time
import os

import pygame.locals

pygame.init()
screen = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
running = True

# world configs
background = pygame.transform.scale(pygame.image.load(os.path.join('assets/background', 'background.png')), (1280, 720))
grass = pygame.transform.scale(pygame.image.load(os.path.join('assets/background', 'grass.png')), (1280, 720))
ground_height = 720 // 2 - 50
gravity = 0.9

# obstacles config
rock_tipes = [pygame.image.load(os.path.join('assets/rocks', 'rock.png')), pygame.image.load(os.path.join('assets/rocks', 'big_rock.png'))]
x_rock = 1280 - 60
rock_velocity = 10
is_spawned = False

# player configs
player = [pygame.image.load(os.path.join('assets/ovo_images', 'egg.png')), pygame.image.load(os.path.join('assets/ovo_images', 'jump_egg.png'))]
x_player, y_player = 80, ground_height
y_velocity = 0
jump_force = -12
in_air = False

# walk sound
pygame.mixer.Sound(os.path.join('assets/sounds', 'walk.mp3')).play(loops=-1)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # setup
    screen.fill("black")
    screen.blit(background, (0, 0))

    # interface
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE] and not in_air:
        pygame.mixer.Sound(os.path.join('assets/sounds', 'jump.mp3')).play()
        y_velocity = jump_force
        in_air = True

    # jump fisics
    if in_air:
        screen.blit(player[1], (x_player, y_player))
        y_velocity += gravity

    if not in_air:
        screen.blit(player[0], (x_player, y_player))

    y_player += y_velocity
    if y_player > ground_height: # hit the ground
        y_player = ground_height
        in_air = False
        y_velocity = 0

    # rock spawn and logic
    if not is_spawned:
        rock = rock_tipes[random.randint(0, 1)]
        is_spawned = True

    elif is_spawned:
        screen.blit(rock, (x_rock, ground_height))
        x_rock -= rock_velocity

        if x_rock == 0:
            x_rock = 1280 - 60
            is_spawned = False

    screen.blit(grass, (0, 1))
        
    pygame.display.flip()
    clock.tick(60)
